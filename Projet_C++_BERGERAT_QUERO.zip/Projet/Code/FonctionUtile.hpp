#ifndef FONCTIONUTILE_HPP_INCLUDED
#define FONCTIONUTILE_HPP_INCLUDED

#include <iostream>

char demandeAouB(std::string a,std::string b,std::string c="",std::string d=""); // verifie si l'utilisateur a bien choisie les valeur proposée
int demandeInt(int b, int c); //verifie le int appartient a l'intervalle [b,c]



#endif // FONCTIONUTILE_HPP_INCLUDED
