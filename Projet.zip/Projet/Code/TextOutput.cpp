#include "TextOutput.hpp"

string TextOutput::textToShow = "";

TextOutput::TextOutput() {}

TextOutput::TextOutput(string text) {}
